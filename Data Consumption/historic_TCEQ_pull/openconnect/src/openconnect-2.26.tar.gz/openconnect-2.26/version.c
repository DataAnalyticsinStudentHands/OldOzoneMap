char openconnect_version[] = "v2.26";
